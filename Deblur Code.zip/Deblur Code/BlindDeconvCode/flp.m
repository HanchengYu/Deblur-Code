function I=flp(I)
    I=fliplr(flipud(I));